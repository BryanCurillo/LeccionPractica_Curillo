package com.prueba.m5a.Leccion;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LeccionApplicationTests {

	@Test
	void contextLoads() {
	}

}
