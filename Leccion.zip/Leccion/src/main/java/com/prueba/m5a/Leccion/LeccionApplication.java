package com.prueba.m5a.Leccion;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LeccionApplication {

	public static void main(String[] args) {
		SpringApplication.run(LeccionApplication.class, args);
	}

}
